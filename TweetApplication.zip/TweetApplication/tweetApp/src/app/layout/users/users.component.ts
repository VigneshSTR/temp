import { Component, OnInit } from '@angular/core';

import { UserList } from '../../models/users-model';
import { UserService } from '../../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [UserService]
})
export class UsersComponent implements OnInit {

  constructor(public userService: UserService) { }
  userList: UserList[] = [];
  searchHappened: boolean = false;
  searchUserList: UserList[] = [];


  errorMessage: string;
  data: boolean = true;
  noData: boolean;
  email: string;

  ngOnInit() {
    this.bindUserDetails();
  }

  inputSearchUser(email: string) {


    this.data = false;
    this.searchHappened = true;
    if (email == "") {

      this.ngOnInit();
    } else {
      this.searchUserList = this.userList.filter(res => {
        return res.email.match(email);
      });

    }

  }
  bindUserDetails() {
    this.userService.getAllUsers().subscribe(data => {
      this.userList = data;
      if (this.userList.length == 0) {
        this.noData = true;

      }
    }, (err) => {
      this.ngOnInit();
      alert(err.message);
      console.log(err);
    });
  }

  searchUser(email: string) {
    if (email == null || email == "" || email == undefined) {
      this.ngOnInit();
      this.searchHappened = false;
      this.data = true;
    }
    else {
      this.userService.searchUser(email).subscribe(data => {
        if (data != undefined || data != null || data != "") {
          this.data = false;
          this.searchHappened = true;
          this.searchUserList = data;
        }
        else {
          this.noData = true;
        }

      })
    }
  }
}
