
import { Tweet } from "./tweet-model";
export class AuthenticateUser {
    email: string;
    password: string;
}
export class ErrorAuthenticateUser {
    errorEmailId: string;
    errorPassword: string;
}
export class UserDetails {
    id: number;
    firstName: string;
    email: string;
    tweets: [];
    success: boolean;
}
export class RegisterUser {
    firstName: string;
    lastName: string;
    dob: string;
    gender: string;
    email: string;
    password: string;
}
export class ErrorRegisterUser {
    error: string;
}
export class ChangePassword {
    id: number;
    password: string;
    newPassword: string;
}
export class ErrorChangePassword {
    errormessage: string;
}
export class User {
    id: number;
    firstName: String;
    email: String;
    message: String;
    tweets: Tweet[];
    errorMessage: String;
    success: boolean;
}