import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';

import { AuthenticateUser,RegisterUser, ChangePassword } from '../models/login-model';



@Injectable({ providedIn: 'root' })
export class LoginService {
  public user: Observable<any>;


  constructor(
    public router: Router,
    public http: HttpClient,
  ) { }

  public AuthenticateUser(_authenticateUser: AuthenticateUser): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user/login",
_authenticateUser);

  }
  public RegisterUser(_registerUser: RegisterUser): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user",
    _registerUser);
  }

  public LogoutUser(id:number): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/logout/"+id);
  }
  public ChangePassword(_changePassword:ChangePassword): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user/reset",_changePassword);
  }
  public getSecurityQuestion(email:string): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/forgotPassword/"+email);
  }

  public forgotPassword(forgotPasswordDetails:any): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user/forgotPassword/",forgotPasswordDetails);
  }

}
