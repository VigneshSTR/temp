import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';
import { UserDetails } from '../models/login-model';




@Injectable({ providedIn: 'root' })
export class TweetsService {
  public user: Observable<any>;


  constructor(
    public router: Router,
    public http: HttpClient,
  ) { }



  public GetAllUserTweets(id:number): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweet/tweets/"+id);
  }
  public GetMyTweets(id:number): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/"+id);

  }
  public PostTweet(_PostTweet:any): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweet/post",_PostTweet);

  }
  public PostTweet1(_PostTweet:any): Observable<UserDetails> {
    return this.http.post<UserDetails>(environment.apiUrl + "/tweet/post", _PostTweet);
  }

}
