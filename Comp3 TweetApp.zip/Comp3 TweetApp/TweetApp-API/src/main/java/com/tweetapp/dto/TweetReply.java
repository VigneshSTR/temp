package com.tweetapp.dto;

public class TweetReply {

}
