package com.tweetapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.dto.AuthenticationRequest;
import com.tweetapp.dto.AuthenticationResponse;
import com.tweetapp.entities.UserModel;
import com.tweetapp.exception.UsernameAlreadyExists;
import com.tweetapp.repositories.UserRepository;
import com.tweetapp.services.UserModelService;

@CrossOrigin(origins = "*")
@RestController
public class AuthController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserModelService userModelService;
	
	
	
	@PostMapping(value="/register")
	public ResponseEntity<?> subscribeClient(@RequestBody UserModel userModel) {
		try {
			UserModel savedUser = userModelService.createUser(userModel);
			return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
		}
		catch (UsernameAlreadyExists e) {
			return new ResponseEntity<>(new AuthenticationResponse(e.getMessage()),
					HttpStatus.CONFLICT);
		}catch (Exception e) {
			return new ResponseEntity<>(new AuthenticationResponse(e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping(value="/login")
	public ResponseEntity<?> authenticateClient(@RequestBody UserModel userModel){
		String username = userModel.getUsername();
		String password = userModel.getPassword();
		try {
			UserModel userMod = userModelService.getUser(username, password);
			return new ResponseEntity<>(userMod,HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(new AuthenticationResponse(e.getMessage()),HttpStatus.UNAUTHORIZED);
		}
		
	}
}
