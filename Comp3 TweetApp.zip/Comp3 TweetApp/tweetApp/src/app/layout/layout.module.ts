import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LayoutRoutes } from './layout.routing';
import { MatDialogModule } from '@angular/material/dialog';
import { MyDialogComponent } from './my-dialog/my-dialog.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LayoutRoutes),
    FormsModule,
    MatDialogModule
  ],
  declarations: [MyDialogComponent],
  entryComponents: [MyDialogComponent],
  exports: [RouterModule,MyDialogComponent],
  providers: [],
})
export class LayoutModule { }
