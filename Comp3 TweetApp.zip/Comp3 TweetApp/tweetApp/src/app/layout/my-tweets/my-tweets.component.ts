import { Component, OnInit } from '@angular/core';

import { MyTweets, PostTweet } from '../../models/tweet-model';
import { TweetsService } from '../../services/tweets.service';
const USER_KEY = "userObject";
@Component({
  selector: 'app-my-tweets',
  templateUrl: './my-tweets.component.html',
  styleUrls: ['./my-tweets.component.css'],
  providers: [TweetsService]
})
export class MyTweetsComponent implements OnInit {

  _MyTweets: MyTweets = new MyTweets();
  _PostTweet: PostTweet = new PostTweet();
  UserDetails: any;
  tweetsAvailable: boolean = false;
  constructor(public _TweetsService: TweetsService) { }


  ngOnInit() {
    this.UserDetails = JSON.parse(localStorage.getItem(USER_KEY));
    this.getUsersTweets();
    this._PostTweet.tweet = "";
  }
  getUsersTweets() {
    this._TweetsService.GetMyTweets(this.UserDetails.id).subscribe(data => {
      this._MyTweets = data;
      if (this._MyTweets.tweets.length == 0) {
        this.tweetsAvailable = false;
      }
      else {
        this.tweetsAvailable = true;
      }
    },
      (err) => {
        this.ngOnInit();
        alert(err.message);
        console.log(err);
      });

  }
  post_btn_click() {
    if (this._PostTweet.tweet == "" || this._PostTweet.tweet == undefined || this._PostTweet.tweet == null) {
      return false;
    }
    else {
      this._PostTweet.user.id = this.UserDetails.id;
      this._TweetsService.PostTweet(this._PostTweet).subscribe(data => {
        if (data.success) {
          this._PostTweet.tweet = "";
          this.getUsersTweets();
        }
      }, (err) => {
        this.ngOnInit();
        alert(err.message);
        console.log(err);
      });
    }

  }
}
