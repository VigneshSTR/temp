import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


import { AuthenticateUser, ErrorAuthenticateUser, UserDetails } from '../../models/login-model';
import { MatDialog } from '@angular/material/dialog';

import { LoginService } from '../../services/login.service';
const USER_KEY = "userObject";

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
  providers: [LoginService]
})

export class LoginPageComponent implements OnInit {


  public AuthenticateUser: AuthenticateUser = new AuthenticateUser();
  public ErrorAuthenticateUser: ErrorAuthenticateUser = new ErrorAuthenticateUser();
  public UserDetails: UserDetails = new UserDetails();


  constructor(public router: Router,
    public dialog: MatDialog,
    private _loginServices: LoginService) { }

  ngOnInit() {
    this.ErrorAuthenticateUser.errorPassword = "";
  }


  login_btn_click() {
    if ((this.AuthenticateUser.email == "" || this.AuthenticateUser.email == undefined || this.AuthenticateUser.email == null) && (this.AuthenticateUser.password == "" || this.AuthenticateUser.password == undefined || this.AuthenticateUser.password == null)) {
      this.ErrorAuthenticateUser.errorPassword = "Enter User Id and Password";
      return false;
    }
    else if (this.AuthenticateUser.email == "" || this.AuthenticateUser.email == undefined || this.AuthenticateUser.email == null) {
      this.ErrorAuthenticateUser.errorPassword = "Enter User Id";
      return false;
    }
    else if (this.AuthenticateUser.password == "" || this.AuthenticateUser.password == undefined || this.AuthenticateUser.password == null) {
      this.ErrorAuthenticateUser.errorPassword = "Enter Password";
      return false;
    }
    else if ((this.AuthenticateUser.email != "" || this.AuthenticateUser.email != undefined || this.AuthenticateUser.email != null) && (this.AuthenticateUser.password != "" || this.AuthenticateUser.password != undefined || this.AuthenticateUser.password != null)) {
      this.ErrorAuthenticateUser.errorEmailId = "";
      this.ErrorAuthenticateUser.errorPassword = "";
      this.authenticateUser(this.AuthenticateUser.email, this.AuthenticateUser.password);
    }
  }

  authenticateUser(_email: string, _password: string) {
    if (_email != null && _password != null) {
      this.AuthenticateUser.email = _email;
      this.AuthenticateUser.password = _password;
      try {
        this._loginServices.AuthenticateUser(this.AuthenticateUser).subscribe((data: any) => {
          localStorage.setItem(USER_KEY, JSON.stringify(data));
          this.UserDetails.email = data.email;
          this.UserDetails.firstName = data.firstName;
          this.UserDetails.tweets = data.tweets;
          this.UserDetails.success = data.success
          if (this.UserDetails.success) {
            this.router.navigate(['tweets']);
          }

          else {
            this.ErrorAuthenticateUser.errorPassword = data.errorMessage;
          }

        },
          (err) => {
            this.AuthenticateUser.email = "";
            this.AuthenticateUser.password = "";
            this.ErrorAuthenticateUser.errorPassword = "";
            alert(err.message);
            console.log(err);
          }
        );
      }
      catch (error) {
      }
    }
  }
  registrationPage() {
    this.router.navigate(['registrationPage']);
  }
}
