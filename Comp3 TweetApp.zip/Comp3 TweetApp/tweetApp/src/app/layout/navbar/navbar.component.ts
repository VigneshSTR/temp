import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService } from '../../services/login.service';

const USER_KEY = "userObject";
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  providers: [LoginService]
})
export class NavbarComponent implements OnInit {

  UserDetails: any;

  constructor(
    public router: Router, private _loginServices: LoginService) { }

  ngOnInit() {
    this.UserDetails = JSON.parse(localStorage.getItem(USER_KEY));
  }
  logout_click() {
    this._loginServices.LogoutUser(Number(this.UserDetails.id)).subscribe((data: any) => {
      if (data == true) {

        alert("User Logged Out Successfully");
        localStorage.clear();
        this.router.navigate(['login']);

      }
    },
      (err) => {
        this.ngOnInit();
        alert(err.message);
        console.log(err);
      });
  }
}
